<template>
  <div class="fullpage">
    <slot></slot>
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
.fullpage {
  height: 100%;
}
</style>
